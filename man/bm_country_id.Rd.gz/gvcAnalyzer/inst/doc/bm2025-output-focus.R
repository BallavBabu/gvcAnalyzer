## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)
library(gvcAnalyzer)

## -----------------------------------------------------------------------------
io <- bm_build_io(
  Z         = bm_toy_Z,
  Y         = bm_toy_Y,
  VA        = bm_toy_VA,
  X         = bm_toy_X,
  countries = bm_toy_countries,
  sectors   = bm_toy_sectors
)

io$countries
io$sectors

## -----------------------------------------------------------------------------
out_comp <- bm_2025_output_components(io)
out_comp

## -----------------------------------------------------------------------------
china_row <- out_comp[out_comp$country == "China", ]
china_row

## -----------------------------------------------------------------------------
out_meas <- bm_2025_output_measures(io)
out_meas

## -----------------------------------------------------------------------------
china_meas <- out_meas[out_meas$country == "China", ]
row_meas   <- out_meas[out_meas$country == "ROW", ]

china_meas[, c("country", "share_GVC_output", "forward_output")]
row_meas[, c("country", "share_GVC_output", "forward_output")]

## -----------------------------------------------------------------------------
out_comp_sec <- bm_2025_output_components_sector(io)
head(out_comp_sec, 9)

## -----------------------------------------------------------------------------
check_agg <- aggregate(
  cbind(DomX_i, TradX_i, GVC_PF_Xi, GVC_PB_Xi, GVC_TS_Xi, GVC_Xi, X_i) ~ country,
  data = out_comp_sec,
  FUN = sum
)

check_agg
out_comp[, c("country", "DomX", "TradX", "GVC_PF_X", "GVC_PB_X", "GVC_TS_X", "GVC_X", "X_total")]

## -----------------------------------------------------------------------------
out_meas_sec <- bm_2025_output_measures_sector(io)
head(out_meas_sec, 9)

## -----------------------------------------------------------------------------
china_sec <- out_meas_sec[out_meas_sec$country == "China", ]
china_sec <- china_sec[order(china_sec$share_GVC_output_i, decreasing = TRUE), ]
china_sec[, c("country", "sector", "share_GVC_output_i", "forward_output_i")]

## -----------------------------------------------------------------------------
manuf_sec <- out_meas_sec[out_meas_sec$sector == "Manufacturing", ]
manuf_sec <- manuf_sec[order(manuf_sec$share_GVC_output_i, decreasing = TRUE), ]
manuf_sec[, c("country", "sector", "share_GVC_output_i", "forward_output_i")]

## ----fig.height=6, fig.width=7------------------------------------------------
par(mfrow = c(2, 2), mar = c(4, 4, 2, 1))
for (ctry in io$countries) {
  ctry_data <- out_meas_sec[out_meas_sec$country == ctry, ]
  barplot(
    height = ctry_data$share_GVC_output_i,
    names.arg = ctry_data$sector,
    main = paste(ctry, "GVC Participation"),
    ylab = "GVC Share of Output",
    col = "steelblue",
    las = 2
  )
}

## ----fig.width=7, fig.height=6------------------------------------------------
par(mar = c(5, 5, 3, 2))
plot(
  out_meas_sec$share_PB_output_i,
  out_meas_sec$share_PF_output_i,
  pch = 19,
  col = as.numeric(factor(out_meas_sec$country)),
  cex = 1.5,
  xlab = "Backward GVC Share",
  ylab = "Forward GVC Share",
  main = "Sectoral GVC Orientation"
)
legend("topright", legend = io$countries, col = 1:io$G, pch = 19, cex = 0.8)
abline(a = 0, b = 1, lty = 2, col = "gray")

## -----------------------------------------------------------------------------
ts_data <- out_comp_sec[out_comp_sec$GVC_TS_Xi > 0, ]
ts_data$TS_import_share <- ts_data$GVC_TSImp_i / ts_data$GVC_TS_Xi

head(ts_data[, c("country", "sector", "GVC_TS_Xi", "GVC_TSImp_i", 
                 "GVC_TSDom_i", "TS_import_share")], 9)

## -----------------------------------------------------------------------------
sessionInfo()

