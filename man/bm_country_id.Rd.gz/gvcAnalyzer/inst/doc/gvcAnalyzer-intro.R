## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 6,
  fig.height = 4
)
library(gvcAnalyzer)

## -----------------------------------------------------------------------------
# Countries and sectors
bm_toy_countries
bm_toy_sectors

# Dimensions
cat("Intermediate flows (Z):", paste(dim(bm_toy_Z), collapse = " × "), "\n")
cat("Final demand (Y):", paste(dim(bm_toy_Y), collapse = " × "), "\n")
cat("Value added (VA):", length(bm_toy_VA), "industries\n")
cat("Gross output (X):", length(bm_toy_X), "industries\n")

## -----------------------------------------------------------------------------
io <- bm_build_io(
  Z         = bm_toy_Z,
  Y         = bm_toy_Y,
  VA        = bm_toy_VA,
  X         = bm_toy_X,
  countries = bm_toy_countries,
  sectors   = bm_toy_sectors
)

# Structure
io$G    # number of countries
io$N    # number of sectors
io$GN   # total industries

## -----------------------------------------------------------------------------
# Single country
bm_2023_exporter_total(io, "China")

# All countries
exporter_totals <- do.call(rbind, lapply(seq_len(io$G), function(g) {
  bm_2023_exporter_total(io, g)
}))
exporter_totals

## -----------------------------------------------------------------------------
# Exports from China to India
bm_2023_bilateral_source(io, "China", "India")

## -----------------------------------------------------------------------------
bm_2023_bilateral_pure(io, "China", "India")

## -----------------------------------------------------------------------------
# Single bilateral pair
bm_2023_tripartite_pair(io, "China", "India")

## -----------------------------------------------------------------------------
trade_comp <- bm_2023_trade_components(io)
trade_comp

## -----------------------------------------------------------------------------
trade_meas <- bm_2023_trade_measures(io)
trade_meas

## -----------------------------------------------------------------------------
out_comp <- bm_2025_output_components(io)
out_comp

## -----------------------------------------------------------------------------
out_meas <- bm_2025_output_measures(io)
out_meas

## -----------------------------------------------------------------------------
out_comp_sec <- bm_2025_output_components_sector(io)
head(out_comp_sec, 9)

## -----------------------------------------------------------------------------
check_agg <- aggregate(
  cbind(DomX_i, TradX_i, GVC_PF_Xi, GVC_PB_Xi, GVC_TSImp_i, 
        GVC_TSDom_i, GVC_TS_Xi, GVC_Xi, X_i) ~ country,
  data = out_comp_sec,
  FUN = sum
)
check_agg[, 1:5]
out_comp[, c("country", "DomX", "TradX", "GVC_PF_X", "GVC_PB_X")]

## -----------------------------------------------------------------------------
out_meas_sec <- bm_2025_output_measures_sector(io)
head(out_meas_sec[, c("country", "sector", "share_GVC_output_i", "forward_output_i")], 9)

## -----------------------------------------------------------------------------
sessionInfo()

